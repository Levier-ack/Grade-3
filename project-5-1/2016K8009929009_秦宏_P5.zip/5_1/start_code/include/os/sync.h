#ifndef INCLUDE_SYNC_H_
#define INCLUDE_SYNC_H_

#include "lock.h"

#endif